#include<stdio.h>

void Display()
{
    printf("Hello 1\n");
    printf("Hello 2\n");
    printf("Hello 3\n");    
    printf("Hello 4\n");
    printf("Hello 5\n");    
}

int main()
{
    Display();

    return 0;
}