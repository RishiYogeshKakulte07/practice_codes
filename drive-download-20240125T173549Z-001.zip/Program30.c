#include<stdio.h>

void Display()
{
    int iCnt = 0;

    for(iCnt = 0; iCnt < 5; iCnt++)
    {
        printf("Jay Ganesh...\n");
    }                
}

int main()
{
    Display();

    return 0;
}